import React from 'react'
import './Card.css'
export default function Card({img,text,cost,btn}) {
  return (
    <div className='Card'>
        <img id='img' src={img} alt=""/>
        <p>{text}</p>
        <br/>
        <h4>{cost}</h4>
        <button className='btn-card' type="">{btn}</button>
    </div>
  )
}

