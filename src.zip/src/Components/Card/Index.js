import React, {useEffect, useState} from 'react'
import {Row,Col} from 'react-bootstrap'
import Card from './Card'
import './Card.css'
export default function Index() {
    const [data,setData] = useState([])
    useEffect(()=>{
        fetch('https://dummyjson.com/products')
        .then(res => res.json())
        .then(responce=>setData(responce));
    },[])
    console.log('data product',data)
    return(<>
    <Row>
        {data['products']?.slice(0,8).map((item,index)=>{
            return(
                <Col lg={3} xl={3}>
        <Card/>
        </Col>
            )
        })}
    </Row>
    </>)
}
