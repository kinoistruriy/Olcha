import React from 'react'
import './Banner.css'
export default function Banner() {
  return (<>
     <div className='banner'>
         <div class="parent-banner">
             <div class="child bg-banner-one"></div>
           </div> 
     </div>
    </>)
}
